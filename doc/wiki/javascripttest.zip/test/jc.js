﻿
var Animal = {
sound : "喵喵喵",
　　　　createNew: function(){
　　　　　　var animal = {};
　　　　　　animal.sleep = "睡懒觉";
　　　　　　return animal;
　　　　}
　　};
var Cat = {
　　　　createNew: function(){
　　　　　　//var cat = Animal.createNew();
            var cat = {};
            cat.speak = "speak";
　　　　　　return cat;
　　　　}
　　};
var cat1 = Cat.createNew();
    //alert(cat1.sound + "---speak=" + cat1.speak); 
   //alert(cat1.sleep);
alert(cat1.speak);