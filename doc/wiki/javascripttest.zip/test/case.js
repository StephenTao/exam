﻿
var iNum = 10;
function test2function(){alert(iNum.toString(2));}
function test8function(){alert(iNum.toString(8));}
function test16function(){alert(iNum.toString(16));}


function int1function(){alert(parseInt("12345fre"));}
function int2function(){alert(parseInt("AF",16));}


